Icon Plugin for Adobe Photoshop
Developer: SibCode
Version: 2.1 (Build 2006-Nov-16)
Platform: Windows 95/98/ME/NT/2000/XP/2003.
Hardware requirements:
32MB RAM, Pentium-233 MHz, 1MB Hard Disk, True Color video mode.

This plugin is FREE SOFTWARE.

The plugin gives Photoshop the ability to open and save windows icons.

Icon Plugin for Photoshop enhances Adobe Photoshop with an ability to
export and import Windows icons (.ico). Thanks to this ability, users
can create icons directly in Adobe Photoshop, using its powerful arsenal
of creative tools and stylistic options. No intermediate files or extra 
icon editors are required. The plug-in supports multi-format icons,
transparency and semi-transparency and allows making icons compatible
with Windows XP and Vista.


* Compatibility *

Photoshop 5.0, 6.0, 7.0 & CS on Windows 98/NT and XP,
Paint Shop Pro 9, Photoshop Elements 3.0


* How to install *

Unpack archive and copy "ico.8bi" and "png.8bi" files
into the "File Formats" folder inside your Photoshop Plugins folder. 
Quit and relaunch Photoshop, if it's already running. 


* How to use the plugin *

Use Photoshop's Open command from the File menu 
to open .ICO files (which will now appear in the file browser) 

Use Photoshop's Save command to create .ICO files 
or to add images to existing icons. 


Trial limitations: none.


The latest release of the application can be downloaded from the 
following link: 
ZIP-file: http://sibcode.com/downloads/icon-plugin.zip

You can find this link on the following page:
http://www.sibcode.com/download.htm


Copyright (C) 2006, SibCode, All rights reserved
Product page: http://www.sibcode.com/icon-plugin/index.htm
